pub fn print_fun(uper:i32,lower:i32){
    for index in uper..lower{
        println!("Downward:{}"index);
    }
}